<template>
  <router-view />
</template>
<style lang="less">
  @import '~@/vab/styles/vab.less';
</style>
